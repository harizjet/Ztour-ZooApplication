const String appLogo = 'assets/icon/icon.png';

const String backdrop =
    'https://firebasestorage.googleapis.com/v0/b/dl-flutter-ui-challenges.appspot.com/o/img%2Fbackdrop.png?alt=media';

const String infoIcon =
    'https://firebasestorage.googleapis.com/v0/b/dl-flutter-ui-challenges.appspot.com/o/img%2Finfo-icon.png?alt=media';

const String ledge =
    'https://www.visitmalaysiatravel.com/pack_images/49380897114a.jpg';
const String photographer =
    'https://www.visitmalaysiatravel.com/pack_images/49380897114a.jpg';

const String loginBack =
    'https://firebasestorage.googleapis.com/v0/b/dl-flutter-ui-challenges.appspot.com/o/img%2Flogin-back.jpg?alt=media';



const String imageSide='https://icons-for-free.com/iconfiles/png/512/avatar+person+profile+user+icon-1320086059654790795.png';